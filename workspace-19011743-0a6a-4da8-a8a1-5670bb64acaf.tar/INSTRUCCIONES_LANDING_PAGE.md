# 🚀 Instrucciones para Personalizar tu Landing Page

¡Felicidades! Tu landing page profesional está lista. Aquí te explico cómo personalizarla:

## 📁 Archivos Principales

- **`src/app/page.tsx`** - Contenido principal de tu landing page
- **`src/app/layout.tsx`** - Configuración SEO y metadatos

## 🎨 Personalización Básica

### 1. Cambiar Titular y Subtítulo
Busca estas líneas en `page.tsx`:
```tsx
<h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-gray-900 mb-6 leading-tight">
  Impulsa tu
  <span className="text-primary block mt-2">Éxito Digital</span>
</h1>

<p className="text-xl md:text-2xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed">
  Descubre las estrategias exactas que han ayudado a miles de emprendedores 
  a escalar sus negocios y alcanzar la libertad financiera que merecen
</p>
```

### 2. Personalizar "Quién Soy Yo"
Busca la sección "¿Quién Soy Yo?" y modifica:
- Tu nombre donde dice "Tu Nombre"
- Tu experiencia y historia
- Los beneficios que ofreces

### 3. Actualizar Partners/Socios
Modifica el array `partners`:
```tsx
const partners = [
  { name: 'Microsoft', logo: 'M' },
  { name: 'Google', logo: 'G' },
  // Agrega tus propios partners
]
```

### 4. Configurar Video
Reemplaza el video placeholder con tu video real:
```tsx
// Donde dice "Aquí iría tu video", agrega:
<video 
  controls 
  className="w-full h-full"
  poster="/tu-thumbnail.jpg"
>
  <source src="/tu-video.mp4" type="video/mp4" />
</video>
```

## 🎯 Personalización Avanzada

### Colores y Tema
- Los colores usan variables de Tailwind: `primary`, `gray-900`, etc.
- Para cambiar el color principal, modifica `tailwind.config.js`

### Tipografía
- Usa las clases de Tailwind: `text-4xl`, `font-bold`, etc.
- Puedes ajustar tamaños según necesites

### Animaciones
- Las animaciones usan clases `transition-all`, `hover:scale-105`, etc.
- Agrega más animaciones según prefieras

## 📱 Responsive Design
La página ya está optimizada para:
- 📱 Móviles (320px+)
- 📟 Tablets (768px+)
- 💻 Desktop (1024px+)
- 🖥️ Pantallas grandes (1280px+)

## 🔧 Configuración SEO
En `layout.tsx` puedes modificar:
- Título y descripción
- Keywords para SEO
- OpenGraph para redes sociales
- Twitter Card

## 🚀 Despliegue
Cuando estés listo para subir a Hostinger:

1. **Build del proyecto:**
   ```bash
   npm run build
   ```

2. **Archivos a subir:**
   - Sube la carpeta `.next`
   - Sube `package.json`
   - Sube `public/`

3. **Instalación en servidor:**
   ```bash
   npm install --production
   npm start
   ```

## 📞 Soporte
Si necesitas ayuda adicional:
- Revisa la consola del navegador para errores
- Verifica que todas las imágenes y videos estén en la carpeta `public/`
- Asegúrate de que los enlaces funcionen correctamente

---

¡Tu landing page está lista para atraer clientes! 🎉