'use client'

import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { Badge } from '@/components/ui/badge'
import { Play, Menu, X, ChevronRight, CheckCircle, Users, Target, Heart, ArrowRight, TrendingUp, Shield, Zap } from 'lucide-react'
import { useState, useEffect } from 'react'

export default function LandingPage() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  useEffect(() => {
    // Cargar el script de Calendly
    const script = document.createElement('script')
    script.src = 'https://assets.calendly.com/assets/external/widget.js'
    script.async = true
    document.body.appendChild(script)

    return () => {
      document.body.removeChild(script)
    }
  }, [])

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
    }
    setIsMobileMenuOpen(false)
  }

  return (
    <div className="min-h-screen bg-white text-black">
      {/* Header Navigation */}
      <header className={`fixed top-0 w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-white/95 backdrop-blur-sm shadow-sm' : 'bg-transparent'}`}>
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16 md:h-20">
            {/* Logo */}
            <div className="flex items-center">
              <h1 className="text-xl md:text-2xl font-bold tracking-tight">
                Álvaro Rojas
              </h1>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-8">
              <button 
                onClick={() => scrollToSection('metodo')}
                className="text-sm md:text-base font-medium hover:text-gray-600 transition-colors"
              >
                Mi Método
              </button>
              <button 
                onClick={() => scrollToSection('problema')}
                className="text-sm md:text-base font-medium hover:text-gray-600 transition-colors"
              >
                El Problema
              </button>
              <button 
                onClick={() => scrollToSection('reserva')}
                className="text-sm md:text-base font-medium hover:text-gray-600 transition-colors"
              >
                Reserva Demo
              </button>
            </nav>

            {/* Mobile Menu Button */}
            <button 
              className="md:hidden p-2"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

          {/* Mobile Navigation */}
          {isMobileMenuOpen && (
            <div className="md:hidden py-4 border-t">
              <nav className="flex flex-col space-y-4">
                <button 
                  onClick={() => scrollToSection('metodo')}
                  className="text-base font-medium text-left hover:text-gray-600 transition-colors"
                >
                  Mi Método
                </button>
                <button 
                  onClick={() => scrollToSection('problema')}
                  className="text-base font-medium text-left hover:text-gray-600 transition-colors"
                >
                  El Problema
                </button>
                <button 
                  onClick={() => scrollToSection('reserva')}
                  className="text-base font-medium text-left hover:text-gray-600 transition-colors"
                >
                  Reserva Demo
                </button>
              </nav>
            </div>
          )}
        </div>
      </header>

      {/* Hero Section */}
      <section className="pt-24 md:pt-32 pb-16 md:pb-24">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto text-center">
            {/* Badge */}
            <Badge className="mb-6 px-4 py-2 text-sm font-medium bg-pink-50 text-pink-700 border-pink-200">
              <Heart className="w-4 h-4 mr-2" />
              Especializado en Marcas de Bienestar Femenino
            </Badge>

            {/* Main Headline */}
            <h1 className="text-3xl md:text-5xl lg:text-6xl font-bold leading-tight mb-8 md:mb-12">
              Existe una fórmula para convertir
              <span className="block text-pink-600 mt-2">clientes de suplementos</span>
              <span className="block mt-2">en fans de por vida</span>
            </h1>

            {/* Sub-headline */}
            <p className="text-xl md:text-2xl text-gray-600 mb-12 max-w-4xl mx-auto leading-relaxed">
              He descubierto el patrón que mantiene al 99% de las marcas del sector de bienestar femenino estancadas. 
              Te enseño el sistema para romper ese ciclo y construir un crecimiento predecible.
            </p>

            {/* Video Section */}
            <div className="mb-12 md:mb-16">
              <div className="relative bg-black rounded-lg overflow-hidden aspect-video max-w-4xl mx-auto">
                <iframe
                  className="w-full h-full"
                  src="https://www.youtube.com/embed/zdrwmXheZqY"
                  title="Video de Reservas de Demo"
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                ></iframe>
              </div>
            </div>

            {/* CTA Button */}
            <div className="mb-16 md:mb-20">
              <Button 
                size="lg"
                className="px-8 md:px-12 py-4 md:py-6 text-lg md:text-xl font-bold bg-pink-600 text-white hover:bg-pink-700 transition-all transform hover:scale-105"
                onClick={() => scrollToSection('reserva')}
              >
                RESERVA UNA HORA ABAJO
                <ArrowRight className="w-5 h-5 md:w-6 md:h-6 ml-2" />
              </Button>
              <p className="text-sm text-gray-500 mt-4">Sesión de claridad estratégica de 15 minutos • Sin compromiso</p>
            </div>
          </div>
        </div>
      </section>

      {/* El Problema Section */}
      <section id="problema" className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
              La Rueda del Hámster del Marketing
            </h2>
            
            <div className="space-y-8">
              <Card className="p-8 border-l-4 border-pink-500">
                <CardContent className="p-0">
                  <h3 className="text-xl md:text-2xl font-bold mb-4 text-gray-900">
                    El Ciclo Infinito que Agota tu Marca
                  </h3>
                  <p className="text-lg text-gray-700 leading-relaxed mb-6">
                    El ciclo es siempre el mismo: foto del producto, lista de beneficios, lanzar anuncios. 
                    Es la rueda del hámster del marketing: anuncio, venta; anuncio, venta.
                  </p>
                  <p className="text-lg text-gray-700 leading-relaxed">
                    Y ese ciclo es agotador, te obliga a competir por precio y hace que tu marca, 
                    que tiene un propósito increíble, sea tratada como una simple commodity.
                  </p>
                </CardContent>
              </Card>

              <div className="text-center">
                <div className="inline-flex items-center gap-4 text-pink-600 font-medium text-lg">
                  <div className="w-12 h-12 bg-pink-100 rounded-full flex items-center justify-center">
                    <Target className="w-6 h-6" />
                  </div>
                  <span>El problema: Tu clienta ya no compra un frasco de vitaminas</span>
                </div>
              </div>

              <Card className="p-8 bg-gradient-to-r from-pink-50 to-purple-50 border-2 border-pink-200">
                <CardContent className="p-0 text-center">
                  <h3 className="text-2xl md:text-3xl font-bold mb-4 text-gray-900">
                    Ella compra confianza, no solo ingredientes
                  </h3>
                  <p className="text-lg text-gray-700 leading-relaxed">
                    Tu clienta compra un paso más hacia la mujer que se quiere convertir.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Mi Sistema Section */}
      <section id="metodo" className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-16">
              Mi Sistema de 3 Pilares
            </h2>
            
            <div className="grid md:grid-cols-3 gap-8 md:gap-12">
              {/* Pilar 1 */}
              <Card className="p-6 md:p-8 border-2 border-pink-200 hover:shadow-lg transition-shadow">
                <CardContent className="p-0 text-center">
                  <div className="w-16 h-16 bg-pink-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Users className="w-8 h-8 text-pink-600" />
                  </div>
                  <div className="text-3xl font-bold mb-4 text-pink-600">01</div>
                  <h3 className="text-xl md:text-2xl font-bold mb-4">Atención y Comunidad</h3>
                  <p className="text-gray-700 leading-relaxed">
                    Creamos contenido de valor que eduque y resuene con los problemas e inspiraciones de tu clienta. 
                    Creamos un espacio donde se sientan escuchadas, antes de siquiera tratar de venderles.
                  </p>
                </CardContent>
              </Card>

              {/* Pilar 2 */}
              <Card className="p-6 md:p-8 border-2 border-pink-200 hover:shadow-lg transition-shadow">
                <CardContent className="p-0 text-center">
                  <div className="w-16 h-16 bg-pink-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Target className="w-8 h-8 text-pink-600" />
                  </div>
                  <div className="text-3xl font-bold mb-4 text-pink-600">02</div>
                  <h3 className="text-xl md:text-2xl font-bold mb-4">Conversión sin Fricción</h3>
                  <p className="text-gray-700 leading-relaxed">
                    En vez de empujar un descuento, construimos un camino educativo que guía a la clienta 
                    hacia la compra de forma natural. Hacemos que la compra sea la consecuencia inevitable 
                    de la confianza que ya hemos generado.
                  </p>
                </CardContent>
              </Card>

              {/* Pilar 3 */}
              <Card className="p-6 md:p-8 border-2 border-pink-200 hover:shadow-lg transition-shadow">
                <CardContent className="p-0 text-center">
                  <div className="w-16 h-16 bg-pink-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Heart className="w-8 h-8 text-pink-600" />
                  </div>
                  <div className="text-3xl font-bold mb-4 text-pink-600">03</div>
                  <h3 className="text-xl md:text-2xl font-bold mb-4">Máxima Retención</h3>
                  <p className="text-gray-700 leading-relaxed">
                    El verdadero valor está en la recurrencia. Convertimos compradoras de una sola vez 
                    en suscriptoras leales, que se convierten en las mejores embajadoras de la marca.
                  </p>
                </CardContent>
              </Card>
            </div>

            <div className="mt-16 text-center">
              <Card className="p-8 bg-gradient-to-r from-pink-600 to-purple-600 text-white border-0">
                <CardContent className="p-0">
                  <h3 className="text-2xl md:text-3xl font-bold mb-4">
                    Crecimiento Predecible y Sostenible
                  </h3>
                  <p className="text-lg leading-relaxed">
                    Cuando este sistema funciona en conjunto, obtienes un crecimiento predecible 
                    que no depende de las modas, los descuentos o la suerte con los algoritmos.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Quien Soy Section */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
              QUIEN SOY
            </h2>
            
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <div className="w-32 h-32 bg-gradient-to-br from-pink-400 to-purple-400 rounded-full mx-auto mb-6 flex items-center justify-center">
                  <span className="text-4xl text-white font-bold">AR</span>
                </div>
              </div>
              
              <div>
                <h3 className="text-2xl font-bold mb-4">Hola, soy Álvaro Rojas</h3>
                <p className="text-lg text-gray-700 leading-relaxed mb-6">
                  Mi nombre es Álvaro Rojas y estoy aquí porque he descubierto el patrón que mantiene 
                  al 99% de las marcas del sector de bienestar femenino estancadas.
                </p>
                <p className="text-lg text-gray-700 leading-relaxed mb-6">
                  He invertido significativamente en mi formación y he estudiado a fondo los sistemas 
                  que funcionan realmente. He desarrollado una metodología basada en procesos probados 
                  que se centran en lo único que importa: crear confianza y comunidad.
                </p>
                <p className="text-lg text-gray-700 leading-relaxed">
                  Mi misión es ayudarte a salir de la rueda del hámster del marketing y construir 
                  una marca que genere fans leales, no solo clientes ocasionales.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mi Metodologia Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-16">
              Mi Metodología
            </h2>
            
            <div className="grid md:grid-cols-2 gap-8 mb-12">
              <Card className="p-6 border-2 border-gray-200">
                <CardContent className="p-0">
                  <div className="flex items-center mb-4">
                    <Zap className="w-6 h-6 text-pink-600 mr-3" />
                    <h3 className="text-xl font-bold">Basado en Procesos, no en Intuición</h3>
                  </div>
                  <p className="text-gray-700">
                    No improvisamos. Aplicamos una fórmula específica y un plan de crecimiento 
                    que sigue una secuencia predecible y probada.
                  </p>
                </CardContent>
              </Card>

              <Card className="p-6 border-2 border-gray-200">
                <CardContent className="p-0">
                  <div className="flex items-center mb-4">
                    <Target className="w-6 h-6 text-pink-600 mr-3" />
                    <h3 className="text-xl font-bold">Pensamiento Sistémico</h3>
                  </div>
                  <p className="text-gray-700">
                    Pensamos en cómo las partes afectan al todo. No nos centramos solo en 
                    "hacer anuncios", sino en el resultado final que queremos conseguir.
                  </p>
                </CardContent>
              </Card>

              <Card className="p-6 border-2 border-gray-200">
                <CardContent className="p-0">
                  <div className="flex items-center mb-4">
                    <TrendingUp className="w-6 h-6 text-pink-600 mr-3" />
                    <h3 className="text-xl font-bold">Embudo Completo, no Servicio Completo</h3>
                  </div>
                  <p className="text-gray-700">
                    Vendemos un proceso completo de adquisición de clientes, no servicios individuales. 
                    Empezamos con el fin en mente: una oferta de adquisición ganadora.
                  </p>
                </CardContent>
              </Card>

              <Card className="p-6 border-2 border-gray-200">
                <CardContent className="p-0">
                  <div className="flex items-center mb-4">
                    <Shield className="w-6 h-6 text-pink-600 mr-3" />
                    <h3 className="text-xl font-bold">Herramientas Orientadas a Ingresos</h3>
                  </div>
                  <p className="text-gray-700">
                    Nos enfocamos exclusivamente en herramientas que tienen un retorno de inversión 
                    monetario claro: Meta Ads, Email Marketing, Creación de embudos.
                  </p>
                </CardContent>
              </Card>
            </div>

            <div className="text-center">
              <p className="text-lg text-gray-600">
                Esta metodología me ha permitido identificar exactamente qué funciona y qué no, 
                eliminando la complejidad y enfocándome solo en lo que genera resultados.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Garantia Section */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
              Mi Garantía para Ti
            </h2>
            
            <Card className="p-8 md:p-12 border-2 border-pink-200">
              <CardContent className="p-0">
                <div className="text-center mb-8">
                  <h3 className="text-2xl md:text-3xl font-bold mb-4 text-gray-900">
                    Sesión de Claridad Estratégica de 15 Minutos
                  </h3>
                  <p className="text-lg text-gray-600">
                    Sin venta, sin presión. Solo valor puro.
                  </p>
                </div>

                <div className="space-y-6">
                  <div className="flex items-start gap-4">
                    <CheckCircle className="w-6 h-6 text-green-500 flex-shrink-0 mt-1" />
                    <div>
                      <h4 className="text-lg font-bold mb-2">1. Identificarás tu cuello de botella</h4>
                      <p className="text-gray-700">
                        Saldrás sabiendo cuál es el cuello de botella número uno por el cual tu marca está estancada.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <CheckCircle className="w-6 h-6 text-green-500 flex-shrink-0 mt-1" />
                    <div>
                      <h4 className="text-lg font-bold mb-2">2. Descubrirás tu diferenciador</h4>
                      <p className="text-gray-700">
                        Descubrirás al menos un nuevo ángulo para tu marketing que te diferenciará de inmediato de tu competencia.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <CheckCircle className="w-6 h-6 text-green-500 flex-shrink-0 mt-1" />
                    <div>
                      <h4 className="text-lg font-bold mb-2">3. Tendrás una acción concreta</h4>
                      <p className="text-gray-700">
                        Te llevarás una acción concreta que podrás implementar esta misma semana para crear una verdadera comunidad.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="mt-8 text-center">
                  <p className="text-lg font-medium text-pink-600 mb-4">
                    El único riesgo es seguir haciendo lo mismo y esperar un resultado diferente.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Reserva Demo Section */}
      <section id="reserva" className="py-16 md:py-24 bg-gradient-to-r from-pink-600 to-purple-600 text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-8">
              ¿Lista para Transformar tu Marca?
            </h2>
            <p className="text-xl mb-12 opacity-90">
              Agenda tu sesión de claridad y déjame mostrarte lo que es posible para tu marca de bienestar femenino.
            </p>
            
            <Button 
              size="lg"
              className="px-12 py-6 text-xl font-bold bg-white text-pink-600 hover:bg-gray-100 transition-all transform hover:scale-105"
              onClick={() => window.open('#calendly', '_self')}
            >
              AGENDA TU DEMO
              <ArrowRight className="w-6 h-6 ml-2" />
            </Button>
            
            <p className="text-lg mt-6 opacity-75">
              Nos vemos en la llamada.
            </p>
          </div>
        </div>
      </section>

      {/* Calendly Integration */}
      <section id="calendly" className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <Card className="p-8 border-2 border-gray-200">
              <CardContent className="p-0">
                <div className="text-center mb-8">
                  <h3 className="text-2xl font-bold mb-4">Agenda tu Sesión de Claridad</h3>
                  <p className="text-gray-600 mb-6">
                    Selecciona el horario que mejor te convenga para nuestra llamada de 15 minutos
                  </p>
                </div>
                
                {/* Calendly Widget */}
                <div className="bg-white rounded-lg overflow-hidden">
                  <div 
                    className="calendly-inline-widget" 
                    data-url="https://calendly.com/alvaro-hym/nueva-reunion" 
                    style={{minWidth: '320px', height: '700px'}}
                  />
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <h3 className="text-xl font-bold mb-4">Álvaro Rojas</h3>
            <p className="text-gray-400 mb-6">
              Especializado en marcas de bienestar femenino
            </p>
            <div className="flex justify-center gap-8 text-sm">
              <a href="#" className="hover:text-white transition-colors">Privacidad</a>
              <a href="#" className="hover:text-white transition-colors">Términos</a>
              <a href="#" className="hover:text-white transition-colors">Contacto</a>
            </div>
            <p className="text-gray-500 text-sm mt-8">
              © 2026 Álvaro Rojas. Todos los derechos reservados.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}