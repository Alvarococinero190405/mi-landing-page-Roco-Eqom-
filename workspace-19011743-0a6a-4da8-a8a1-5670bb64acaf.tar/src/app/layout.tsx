import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Álvaro Rojas | Especialista en Marcas de Bienestar Femenino',
  description: 'Convierte clientes de suplementos en fans de por vida. Descubre el sistema de 3 pilares para escalar tu marca de bienestar femenino con crecimiento predecible y sostenible.',
  keywords: 'bienestar femenino, suplementos, marketing, retención clientes, comunidad, conversión sin fricción, Álvaro Rojas',
  icons: {
    icon: '/favicon.png',
    shortcut: '/favicon.png',
    apple: '/favicon.png',
  },
  openGraph: {
    title: 'Álvaro Rojas | Especialista en Marcas de Bienestar Femenino',
    description: 'El sistema para convertir clientes de suplementos en fans de por vida',
    type: 'website',
    locale: 'es_ES',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Álvaro Rojas | Especialista en Marcas de Bienestar Femenino',
    description: 'Convierte clientes de suplementos en fans de por vida con mi sistema de 3 pilares',
  },
  robots: {
    index: true,
    follow: true,
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="es">
      <body className={inter.className}>{children}</body>
    </html>
  )
}